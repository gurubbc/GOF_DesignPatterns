package behavioral;

class CEO extends ApprovalPower
{

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with CEO for Rs. "+buyRequest.getBillAmount());
		if (buyRequest.getBillAmount()>4000 && buyRequest.getBillAmount()<=5000)
			System.out.println("CEO will approve Rs.  "+buyRequest.getBillAmount());
		else
		{
			System.out.println("We need a borad meeting to approve Rs. "+buyRequest.getBillAmount());
		}
		
	}
	
}
