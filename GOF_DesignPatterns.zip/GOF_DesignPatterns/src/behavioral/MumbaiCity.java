package behavioral;

public class MumbaiCity extends City{

	WeatherStation ws;

	MumbaiCity(WeatherStation ws)
	{
		this.ws=ws;
	}
	
	@Override
	public void update() {
		System.out.println("Mumbai city is getting updates from WeatherStation ...."+ws.getMsg());
		
	}


}
