package behavioral;

public class ChainOfResponsibility {

	public static void main(String[] args) {
		Manager m=new Manager();
		SrManager srm=new SrManager();
		Director d=new Director();
		VP vp=new VP();
		President p=new President();
		CEO c=new CEO();
		
		
		m.setNextLevel(srm);
		srm.setNextLevel(d);
		d.setNextLevel(vp);
		vp.setNextLevel(p);
		p.setNextLevel(c);
		c.setNextLevel(null);
		
		BuyRequest br=new BuyRequest(12, 5000, "Training");
		m.processBill(br);
	}
}
