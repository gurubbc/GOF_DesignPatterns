package behavioral;

public class PhysicalStoreShopping extends OrderProcessTemplate{

	@Override
	public void payAmount() {
		System.out.println("Pay by cash");
	}

	@Override
	public void selectItems() {
		System.out.println("Select items from the shelf and put into the trolley");
		
	}

	@Override
	public void deliverItems() {
		System.out.println("Put all items into a bag and carry");
		
	}


	@Override
	public void fillDetailsForBumperPrize() {
		System.out.println("Fill your email and phone, we will inform you in case you win");
		
	}

	
}
