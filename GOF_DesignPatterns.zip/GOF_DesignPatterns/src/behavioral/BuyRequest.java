package behavioral;

class BuyRequest
{
	int billNo;
	double billAmount;
	String purpose;
	
	public BuyRequest(int billNo, double billAmount, String purpose) {
		super();
		this.billNo = billNo;
		this.billAmount = billAmount;
		this.purpose = purpose;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	
	
}
