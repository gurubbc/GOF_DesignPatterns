package behavioral;

class Parents implements Relative
{

	boolean mood=true;
	@Override
	public void accept(PersonalVisitor visitor) {
		visitor.visit(this);
		
	}
	
}
