package behavioral;

class ChennaiCity extends City
{
	WeatherStation ws;
	
	ChennaiCity(WeatherStation ws)
	{
		this.ws=ws;
	}

	@Override
	public void update() {
		System.out.println("Chennai city is getting updates from WeatherStation ...."+ws.getMsg());
		
	}
	
}
