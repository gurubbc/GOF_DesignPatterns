package behavioral;

class EmailIterator implements MyIterator 
{ 
    Email[] emailList; 
  
    // maintains curr pos of iterator over the array 
    int pos = 0; 
  
    // Constructor takes the array of notifiactionList are 
    // going to iterate over. 
    public  EmailIterator (Email[] emailList) 
    { 
        this.emailList = emailList; 
    } 
  
    public Object next() 
    { 
        // return next element in the array and increment pos 
        Email email =  emailList[pos]; 
        pos += 1; 
        return email; 
    } 
  
    public boolean hasNext() 
    { 
        if (pos >= emailList.length || 
            emailList[pos] == null) 
            return false; 
        else
            return true; 
    } 
} 
