package behavioral;

class SpeedIncreaseState implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan spin gains momentum....");
		
	}
	
}
