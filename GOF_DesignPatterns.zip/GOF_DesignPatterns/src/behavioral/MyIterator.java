package behavioral;

interface MyIterator 
{ 
    // indicates whether there are more elements to 
    // iterate over 
    boolean hasNext(); 
  
    // returns the next element 
    Object next(); 
    
    // Implement this
//    boolean hasPrevious();
    
//    Object previous();
} 
