package behavioral;

public interface Strategy {
	public void applyStrategy();
}
