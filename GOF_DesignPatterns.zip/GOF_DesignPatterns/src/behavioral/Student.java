package behavioral;

import java.io.Serializable;

class Student implements Serializable
{
	String name;
	int marks;
	
	public Student() {}
	
	public Student(String name, int marks)
	{
		this.name=name;
		this.marks=marks;
	}
}
