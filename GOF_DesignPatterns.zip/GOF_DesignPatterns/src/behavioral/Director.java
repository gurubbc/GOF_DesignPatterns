package behavioral;
class Director extends ApprovalPower
{

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with director for Rs. "+buyRequest.getBillAmount());
		if (buyRequest.getBillAmount()> 1000 & buyRequest.getBillAmount()<=2000)
			System.out.println("Director will approve Rs.  "+buyRequest.getBillAmount());
		else
		{
			if (nextLevel!=null)
				nextLevel.processBill(buyRequest);
		}
		
	}
	
}
