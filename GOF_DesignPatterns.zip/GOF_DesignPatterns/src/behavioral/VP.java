package behavioral;

class VP extends ApprovalPower
{

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with VP for Rs. "+buyRequest.getBillAmount());
		if (buyRequest.getBillAmount()>2000 & buyRequest.getBillAmount()<=3000)
			System.out.println("VP will approve Rs.  "+buyRequest.getBillAmount());
		else
		{
			if (nextLevel!=null)
				nextLevel.processBill(buyRequest);
		}
		
	}
	
}
