package behavioral;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<Integer> aList=new ArrayList<Integer>();
		aList.add(55);
		aList.add(155);
		aList.add(255);
		aList.add(555);
		aList.add(525);
		
		Iterator<Integer> it=aList.iterator();
		int bigNumber=0;
		
		
		while (it.hasNext())
		{
			//
			int no=(Integer)it.next();
			System.out.println("The number is "+no);
			if (no > bigNumber)
			{
				bigNumber = no;
			}
		} // end of while loop
		System.out.println("The biggest number found is "+bigNumber);
		

	}

}
