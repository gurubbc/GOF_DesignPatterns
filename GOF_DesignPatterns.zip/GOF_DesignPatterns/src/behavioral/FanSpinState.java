package behavioral;

interface FanSpinState
{
	public void spin();
}
