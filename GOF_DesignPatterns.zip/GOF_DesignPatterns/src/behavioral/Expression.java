package behavioral;

interface Expression {
	public int interpret(InterpreterEngine ie);
}
