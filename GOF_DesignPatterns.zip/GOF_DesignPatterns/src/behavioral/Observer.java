package behavioral;

public class Observer
{
	public static void main(String[] args) {
		WeatherStation ws=new WeatherStation();
		MumbaiCity mc=new MumbaiCity(ws);// observer class
		ChennaiCity cc=new ChennaiCity(ws);
		BangaloreCity bb=new BangaloreCity(ws);
		
		ws.subscribe(mc);
		ws.subscribe(bb); // bangalore city
		
		ws.setMsg("Corona alert"); // state is changed
		
		ws.unsubscribe(bb); // bangalore city
//		
		ws.setMsg("Tsunami alert"); // state is changed
//		
		ws.unsubscribe(mc);
		
		ws.subscribe(mc);
		ws.setMsg("Earthquake alert");
	}
}
