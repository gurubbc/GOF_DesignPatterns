package behavioral;

class Children implements Relative
{

	@Override
	public void accept(PersonalVisitor visitor) {
		visitor.visit(this);
		
	}

	
}
