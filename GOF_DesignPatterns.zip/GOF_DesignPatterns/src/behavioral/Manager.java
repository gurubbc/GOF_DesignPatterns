package behavioral;

class Manager extends ApprovalPower
{

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with manager for Rs. "+buyRequest.getBillAmount());
		if (buyRequest.getBillAmount()<=1000)
			System.out.println("Manager will approve Rs.  "+buyRequest.getBillAmount());
		else
		{
			if (nextLevel!=null)
				nextLevel.processBill(buyRequest);
		}
		
	}
	
}
