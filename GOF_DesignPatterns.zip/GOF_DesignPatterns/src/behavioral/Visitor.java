package behavioral;

interface Visitor
{
	void visit(Parents p);
	void visit(Children c);
	
}
