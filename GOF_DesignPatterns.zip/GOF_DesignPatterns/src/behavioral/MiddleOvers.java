package behavioral;

public class MiddleOvers implements Strategy{

	@Override
	public void applyStrategy() {
		System.out.println("Look for boundaries possible, try not losing wikets, but runs are equally important as wickets");
	}

}
