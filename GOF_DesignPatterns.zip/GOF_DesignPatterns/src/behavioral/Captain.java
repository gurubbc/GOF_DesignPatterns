package behavioral;

class Captain
{
	Strategy strategy;

	public Captain(Strategy strategy) {
		super();
		this.strategy = strategy;
	}
	
	public void applyStrategy()
	{
		strategy.applyStrategy();
	}
	
}
