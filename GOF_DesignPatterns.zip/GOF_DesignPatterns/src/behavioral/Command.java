package behavioral;

public class Command {

	public static void main(String[] args) {
		Project p1=new Project();
		// Requests
		ProjectRequirements pr=new ProjectRequirements(p1);
		ProjectDelivery pd=new ProjectDelivery(p1);
		ProjectMaintenance pmt=new ProjectMaintenance(p1);
		BugFixing bugs=new BugFixing(p1);
		
		//Invoker
		ProjectManager pm=new ProjectManager();
		pm.takeProject(pr);
		pm.takeProject(pd);
		pm.takeProject(bugs);
		
		pm.executeProjects();
		
		
		
	}
}
