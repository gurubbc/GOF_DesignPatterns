package behavioral;

class ReverseSpin implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan started spinning in the reverse direction....");
		
	}
	
}
