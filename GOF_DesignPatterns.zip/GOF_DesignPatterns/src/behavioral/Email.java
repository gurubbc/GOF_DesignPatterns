package behavioral;

class Email
{
	String msg;
	
	public Email(String msg)
	{
		this.msg=msg;
	}

	public String getMsg() {
		return msg;
	}

	@Override
	public String toString() {
		return msg;
	}
	
}
