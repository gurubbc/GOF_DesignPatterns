package behavioral;

public class VisitorDemo {
	public static void main(String[] args) {
		Parents p=new Parents();
		PersonalVisitor v=new PersonalVisitor(); // we are visiting our parents
//		p.accept(v);
		
		Children c=new Children();
		c.accept(v);
	}
}
