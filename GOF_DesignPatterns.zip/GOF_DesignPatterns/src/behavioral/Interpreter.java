package behavioral;

public class Interpreter {
	
	private InterpreterEngine ie;
	
	public Interpreter(InterpreterEngine ie) {
		this.ie = ie;
	}
	
	public int interpret(String input) {
		
		Expression exp = null;
		
		if(input.contains("add")) {
			exp = new AddExpression(input);
		} 
		
		int result = exp.interpret(ie);
		System.out.println(input);
		
		return result;
	}
	
	public static void main(String args[]) {
		
		Interpreter ic = new Interpreter(new InterpreterEngine());
		
		System.out.println("Result = " + ic.interpret("add 18 and 42"));
		System.out.println("Result = " + ic.interpret("subtract 15 from 25"));
		
	
	}
}
