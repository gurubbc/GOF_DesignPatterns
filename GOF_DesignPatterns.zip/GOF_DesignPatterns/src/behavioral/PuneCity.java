package behavioral;

class PuneCity extends City
{
	WeatherStation ws;
	
	PuneCity(WeatherStation ws)
	{
		this.ws=ws;
	}

	@Override
	public void update() {
		System.out.println("Pune city is getting updates from WeatherStation ...."+ws.getMsg());
		
	}
	
}
