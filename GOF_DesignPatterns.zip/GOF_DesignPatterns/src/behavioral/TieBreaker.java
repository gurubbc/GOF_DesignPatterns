package behavioral;

public class TieBreaker implements Strategy{

	@Override
	public void applyStrategy() {
		System.out.println("Get more runs");
		
	}

}
