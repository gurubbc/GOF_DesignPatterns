package behavioral;

class Project
{
	public void bugFixing()
	{
		System.out.println("Fixing the bug");
	}
	
	public void getRequirements()
	{
		System.out.println("Getting new requirements");
	}
	
	public void deliverProjects()
	{
		System.out.println("Deliver the project");
	}
	
	public void maintainProjects()
	{
		System.out.println("Maintain the project");
	}
	
	public void planProjects()
	{
		System.out.println("planning the projects");
	}
}

