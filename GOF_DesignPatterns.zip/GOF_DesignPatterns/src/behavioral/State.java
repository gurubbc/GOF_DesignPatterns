package behavioral;

public class State {
	public static void main(String[] args) {
		SpinStateContext stateContext=new SpinStateContext();
		stateContext.spin();
		System.out.println("The current state is "+stateContext.currentState);
//		
		stateContext.setState(new StartState()); // changing the state
		System.out.println("The current state is "+stateContext.currentState);
		stateContext.spin();
		
		
//////		
		stateContext.setState(new SpeedIncreaseState());
		stateContext.spin();
		System.out.println("The current state is "+stateContext.currentState);
//////		
//		stateContext.setState(new SpeedDecreaseState());
//		stateContext.spin();
////
////		
//		stateContext.setState(new StopState());
//		stateContext.spin();
////		
//		stateContext.setState(new ReverseSpin());
//		stateContext.spin();
//		
//		// set the new state and check how spin() behaviour changes
//		stateContext.setState(new JumpState());
//		stateContext.spin();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
