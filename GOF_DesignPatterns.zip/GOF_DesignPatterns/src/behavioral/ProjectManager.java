package behavioral;

import java.util.ArrayList;

//Invoker class
class ProjectManager
{
	ArrayList<Work> allWork=new ArrayList<Work>();
	
	public void takeProject(Work w)
	{
		allWork.add(w);
	}
	
	public void executeProjects()
	{
		System.out.println("Project Manager executing the following tasks");
		for (Work w:allWork)
		{
			w.execute(); // command pattern
			// Different requests are encapsulated inside a command method, you can give any name
		}
	}
	
}
