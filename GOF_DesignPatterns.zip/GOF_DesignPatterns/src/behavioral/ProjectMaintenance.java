package behavioral;

public class ProjectMaintenance implements Work{

	Project project;
	
	
	
	public ProjectMaintenance(Project project) {
		super();
		this.project = project;
	}



	@Override
	public void execute() {
		project.maintainProjects();
		
	}

	
}
