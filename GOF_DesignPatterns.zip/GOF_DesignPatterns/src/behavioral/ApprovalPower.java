package behavioral;

abstract class ApprovalPower
{
	ApprovalPower nextLevel;
	
	public void setNextLevel(ApprovalPower nextLevel)
	{
		this.nextLevel=nextLevel;
	}
	
	abstract public void processBill(BuyRequest buyRequest);
}
