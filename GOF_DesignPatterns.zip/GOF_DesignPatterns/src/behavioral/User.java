package behavioral;

public class User {
	String name;

	public User(String name) {
		this.name = name;
	}
	
	public void sendMsg(String msg)
	{
		MyProject.showMsg(this,msg);
	}
	

}
