package behavioral;

public class OnlineShopping extends OrderProcessTemplate {

	@Override
	public void payAmount() {
		System.out.println("Pay by credit card/debit card or Net banking");
		
	}

	@Override
	public void selectItems() {
		System.out.println("Choose the item from the drop down and add it to the shopping cat");
		
	}

	@Override
	public void deliverItems() {
		System.out.println("Shops will deliver based on the time slot");
		
	}

	@Override
	public void fillDetailsForBumperPrize() {
		System.out.println("Fill your email and phone, we will inform you in case you win");
		
	}

	
}
