package behavioral;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializationDemo {
	// Application at the receiving end
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileInputStream fis=new FileInputStream("student.ser");
		ObjectInputStream ois=new ObjectInputStream(fis); // wrapper around
		Student stObj=(Student)ois.readObject();// reconstruction of the obj
		System.out.println(stObj.name+" and "+stObj.marks);
		
	}

}
