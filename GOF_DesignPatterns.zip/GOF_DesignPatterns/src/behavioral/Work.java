package behavioral;
interface Work
{
	public void execute();
}
