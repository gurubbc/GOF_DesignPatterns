package behavioral;

public class BugFixing implements Work {

	Project project;

	public BugFixing(Project project) {
		super();
		this.project = project;
	}

	@Override
	public void execute() {
		System.out.println("Work: Fixing the bug");
		project.bugFixing();
		
	}
	
	
	
	
}
