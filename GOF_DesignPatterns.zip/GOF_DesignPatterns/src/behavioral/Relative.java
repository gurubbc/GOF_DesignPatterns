package behavioral;

interface Relative
{
	public void accept(PersonalVisitor visitor);
}
