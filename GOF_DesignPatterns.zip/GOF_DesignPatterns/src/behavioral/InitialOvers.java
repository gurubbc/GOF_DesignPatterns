package behavioral;

public class InitialOvers implements Strategy{

	@Override
	public void applyStrategy() {
		System.out.println("Take singles, don't lose wickets");
	}

}
