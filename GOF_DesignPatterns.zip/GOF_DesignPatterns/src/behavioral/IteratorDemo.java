package behavioral;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class IteratorDemo {

	public static void main(String[] args) {
		EmailCollection ec = new EmailCollection(); // COLLECTION OBJECT (ArrayList)
		ec.addEmailItem(new Email("5th email"));
		ec.addEmailItem(new Email("6th email"));
	
		MyIterator it=ec.createIterator(); // iterator() gives Iterator object
		while (it.hasNext())
			System.out.println(it.next());
         
//		// existing class from JDK
//		Set s=new HashSet<String>();
//		s.add("one");
//		s.add("two");
//		s.add("three");
//		
//		Iterator it1=s.iterator();
//		while (it1.hasNext())
//		{
//			System.out.println(it1.next());
//		}
		
	}
}
