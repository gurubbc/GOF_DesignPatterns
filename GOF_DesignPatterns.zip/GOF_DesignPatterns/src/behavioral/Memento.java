package behavioral;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Memento {
	
	// How to serialize Student object
	public static void main(String[] args) throws IOException {
		Student st1=new Student("Sayali", 99); // state
		
		FileOutputStream fos=new FileOutputStream("student.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos); //wrapper
		
		
		oos.writeObject(st1);
		oos.close();
		fos.close();
		System.out.println("Successfully serialized");
		
		// Deserialization
		try {
		FileInputStream fis=new FileInputStream("student.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Student s2=(Student)ois.readObject();
		System.out.println(s2.name+" and "+s2.marks);
		
		}
		catch(ClassNotFoundException ce)
		{
			System.out.println(ce.getMessage());
		}
		
		
		
		
		
		
		
		
	}
}
