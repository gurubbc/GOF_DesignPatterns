package behavioral;

class StopState implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan stopped..");
		
	}
	
}
