package behavioral;

class President extends ApprovalPower
{

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with President for Rs. "+buyRequest.getBillAmount());
		if (buyRequest.getBillAmount()>3000 && buyRequest.getBillAmount()<=4000)
			System.out.println("President will approve Rs.  "+buyRequest.getBillAmount());
		else
		{
			if (nextLevel!=null)
				nextLevel.processBill(buyRequest);
		}
		
	}
	
}
