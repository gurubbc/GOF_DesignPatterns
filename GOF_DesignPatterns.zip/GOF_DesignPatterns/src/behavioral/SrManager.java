package behavioral;

public class SrManager extends ApprovalPower {

	@Override
	public void processBill(BuyRequest buyRequest) {
		System.out.println("Checking with Sr. Manager");
		if (buyRequest.getBillAmount()>1000 & buyRequest.getBillAmount()<1500)
		{
			System.out.println("Yes, Sr Manager can approve");
		}
		else
		{
			if (nextLevel!=null)
			{
				nextLevel.processBill(buyRequest);
			}
		}
		
	}

}
