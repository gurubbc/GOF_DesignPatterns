package behavioral;

class IdleState implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan initial state ... idle...not spinning...");
		
	}
	
}
