package behavioral;

public class JumpState implements FanSpinState {

	@Override
	public void spin() {
		System.out.println("Fan started jumping...");
		
	}

}
