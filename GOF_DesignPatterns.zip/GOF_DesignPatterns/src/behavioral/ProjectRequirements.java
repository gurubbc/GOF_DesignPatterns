package behavioral;
class ProjectRequirements implements Work
{
	Project prj;
	
	public ProjectRequirements(Project prj) {
		this.prj=prj;
	}

	@Override
	public void execute() {
		prj.getRequirements();
		
	}
	
}
