package behavioral;

class EmailCollection implements MyCollection 
{ 
    static final int MAX_ITEMS = 6; 
    Email[] emailList; 
  
    public void addEmailItem(Email email) {
    	emailList[4]=email;
    }
    
    
    public EmailCollection() 
    { 
    	emailList = new Email[MAX_ITEMS]; 
  
        // Let us add some dummy emails 
        Email e1=new Email("Email msg 1"); 
        Email e2=new Email("Email msg 2");
        Email e3=new Email("Email msg 3");
        Email e4=new Email("Email msg 4");
        emailList[0]=e1;
        emailList[1]=e2;
        emailList[2]=e3;
        emailList[3]=e4;
        
    } 
  
 
  
    public MyIterator createIterator() 
    { 
        return new EmailIterator(emailList); 
    } 
}
