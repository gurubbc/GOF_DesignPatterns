package behavioral;

class BangaloreCity extends City
{

	WeatherStation ws;
	
	BangaloreCity(WeatherStation ws)
	{
		this.ws=ws;
	
	}
	
	public void subscribe()
	{
		this.ws.subscribe(this);
	}
	
	public void unsubscribe()
	{
		
	}
	
	@Override
	public void update() {
		System.out.println("Bangalore city is getting notified from WeatherStation ...."+ws.getMsg());
		
	}
	
}
