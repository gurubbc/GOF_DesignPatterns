package behavioral;

import java.util.ArrayList;
import java.util.List;

class WeatherStation
{
	List<City> allCities=new ArrayList<City>();
	String msg;
	
	public String getMsg()
	{
		return msg;
	}
	
	public void setMsg(String msg)
	{
		this.msg=msg;
		notifyAllCities();
	}
	
	
	public void subscribe(City c)
	{
		allCities.add(c);
	}
	
	
	public void unsubscribe(City c)
	{
		allCities.remove(c);
		System.out.println("The city has been successfully unsubscried");
	}
	public void notifyAllCities()
	{
		for (City c:allCities)
		{
			c.update();
		}
	}
	
}
