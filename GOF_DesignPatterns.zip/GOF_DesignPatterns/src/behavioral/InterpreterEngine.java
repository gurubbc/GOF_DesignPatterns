package behavioral;

public class InterpreterEngine {

	// Input:add 15 and 21
	public int add(String input) {
		System.out.println("Going to add input is "+input);
		String[] tokens = interpret(input);
		int sum=0;
		for (int i=0;i<tokens.length;i++)
			sum=sum+Integer.parseInt(tokens[i]);
		return sum;
				
	}

	// Input:   add 15 and 21
	// becomes: ____15_____21
	// String[] tokens= [15,21]
	private String[] interpret(String input) {
		String str = input.replaceAll("[^0-9]", " ");
		System.out.println("one: "+ str);
		str = str.replaceAll("( )+", " ").trim();
		System.out.println("two: "+str);
		String[] tokens = str.split(" ");
		return tokens;
	}

}
