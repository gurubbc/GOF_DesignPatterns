package behavioral;

public class ImpactPlayer implements Strategy{

	@Override
	public void applyStrategy() {
		System.out.println("Get the best batsman in place of bowler if we want to score more runs");
		
	}
}