package behavioral;

abstract class City {
	WeatherStation ws;
	public abstract void update();
}
