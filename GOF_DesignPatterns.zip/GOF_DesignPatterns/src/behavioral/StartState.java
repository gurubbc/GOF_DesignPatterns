package behavioral;

class StartState implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan started spinning");
		
	}
	
}
