package behavioral;

class PersonalVisitor implements Visitor
{

	@Override
	public void visit(Parents p) {
		if (p.mood==false) // they are in bad mood
			System.out.println("Not visiting");
		else
			System.out.println("Namste parents....paying respect, enquire about health");
		
	}

	@Override
	public void visit(Children c) {
		System.out.println("Hello....enquire about studies");
		
	}
	
}
