package behavioral;

class SpinStateContext
{
	FanSpinState currentState; // off, on, increase, decrease
	
	public SpinStateContext()
	{
		currentState=new IdleState();
		
	}
	
	public void setState(FanSpinState state)
	{
		currentState=state;
		
	}
	
	public void spin()
	{
		currentState.spin();
	}

	@Override
	public String toString() {
		return "SpinStateContext [currentState=" + currentState + "]";
	}
	
	
}
