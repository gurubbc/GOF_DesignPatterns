package behavioral;

interface MyCollection 
{ 
    public MyIterator createIterator(); 
} 
