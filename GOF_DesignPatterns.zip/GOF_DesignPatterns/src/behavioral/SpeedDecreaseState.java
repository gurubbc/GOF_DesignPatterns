package behavioral;

class SpeedDecreaseState implements FanSpinState
{

	@Override
	public void spin() {
		System.out.println("Fan spin losing momentum....");
		
	}
	
}
