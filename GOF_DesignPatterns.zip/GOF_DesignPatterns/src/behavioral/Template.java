package behavioral;

public class Template {

	public static void main(String[] args) {
		OnlineShopping os=new OnlineShopping();
		os.processOrder();
		
		PhysicalStoreShopping pss=new PhysicalStoreShopping();
		pss.processOrder();

	}

}
