package behavioral;
//Mediator class
class MyProject
{
	// You can define an array here
	// You can assign all usernames into this array
	// so that you can decide whom to show this msg.
	static String  projectName;
	
	public MyProject(String projectName) {
		this.projectName = projectName;
	}

	public static void showMsg(User u, String msg)
	{
		// You can have all control here
		// Like whom to show, how to show, add some moods to the messages
		if (u.name.equalsIgnoreCase("Guru"))
		{
			System.out.println("He is teaching now");

		}
		
		if (msg.contains("gamble"))
			System.out.println("This message is resticted, can't send to the receiver");
		else 
			System.out.println(projectName+":"+u.name+"> "+msg);
	}
}
