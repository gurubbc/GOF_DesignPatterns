package behavioral;

public abstract class OrderProcessTemplate {
	public abstract void payAmount();
	public abstract void selectItems();
	public abstract void deliverItems();
	public abstract void fillDetailsForBumperPrize();
	
	// templating part
	public final void processOrder()
	{
		selectItems();
		payAmount();
		fillDetailsForBumperPrize();
		deliverItems();
		
	}
	
}
