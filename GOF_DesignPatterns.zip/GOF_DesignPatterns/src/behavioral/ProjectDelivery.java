package behavioral;

public class ProjectDelivery implements Work{

	Project project;
	
	
	public ProjectDelivery(Project project) {
		super();
		this.project = project;
	}

	@Override
	public void execute() {
		System.out.println("Work: Delivering the project");
		project.deliverProjects();
		
	}

	
}
