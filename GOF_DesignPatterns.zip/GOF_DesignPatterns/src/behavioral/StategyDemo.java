package behavioral;

public class StategyDemo {

	public static void main(String[] args) {
		InitialOvers io=new InitialOvers();  // strategy name
		Captain c=new Captain(io); // context, applies the strategy
//		c.applyStrategy(); // calling the method
		
		MiddleOvers mo=new MiddleOvers(); // 2nd strategy
		c.strategy=mo;
		c.applyStrategy();
//////		
		DeathOvers doo=new DeathOvers();
		c.strategy=doo;
		c.applyStrategy();
//////		
		TieBreaker tb=new TieBreaker();
		c.strategy=tb;
		c.applyStrategy();
////		
		ImpactPlayer ip=new ImpactPlayer();
		c.strategy=ip;
		c.applyStrategy();
		
	}
}
