package behavioral;

public class Mediator {

	public static void main(String[] args) {
		MyProject mp1=new MyProject("walmart");
		User user1=new User("Guru");
		user1.sendMsg("Hello Ram");
		user1.sendMsg("Want to study?");
		
		MyProject mp2=new MyProject("ecommerce");
		User user2=new User("Ram");
		user2.sendMsg("Hi Guru");
	}
}
