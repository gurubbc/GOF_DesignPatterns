package behavioral;

public class DeathOvers implements Strategy{

	@Override
	public void applyStrategy() {
		System.out.println("don't worry about wickets...try hitting hard to get more sixes and boundaries");
		
	}

	
}
