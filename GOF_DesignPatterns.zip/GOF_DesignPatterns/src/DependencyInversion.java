// High-level module
class PaymentProcessor {
    private PaymentMethod paymentMethod;

    public PaymentProcessor(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void processPayment(double amount) {
        paymentMethod.pay(amount);
    }
}

// Abstraction
interface PaymentMethod {
	void pay(double amount);
}

// Low-level modules
class CreditCardPayment implements PaymentMethod {
    public void pay(double amount) {
    	 System.out.println("Paid $" + amount + " via credit card.");
        // Credit card payment implementation
    }
}

class PayPalPayment implements PaymentMethod {
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " via PayPal.");
        // PayPal payment implementation
    }
}

public class DependencyInversion {
	public static void main(String[] args) {
		PaymentMethod paymentMethod=new CreditCardPayment();
		PaymentProcessor pp=new PaymentProcessor(paymentMethod);
		pp.processPayment(1235.5);
	}
	
}
