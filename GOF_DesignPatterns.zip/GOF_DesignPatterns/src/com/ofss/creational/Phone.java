package com.ofss.creational;

public interface Phone {
	void phoneDetails();
}
