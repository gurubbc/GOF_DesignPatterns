package com.ofss.creational;

public class SmartPhone implements Phone{

	@Override
	public void phoneDetails() {
		System.out.println("Smart Phone");
		
	}

}
