package com.ofss.creational;

public class Circle implements Shape{

	@Override
	public void draw() {
		System.out.println("Drawing Circle");
		System.out.println("Changing the implementation for this class");
		
	}

}
