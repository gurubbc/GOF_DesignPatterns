package com.ofss.creational;

import java.util.*;

interface Item
{
	public String name();
	public double price();
	public Packing packing();
}
