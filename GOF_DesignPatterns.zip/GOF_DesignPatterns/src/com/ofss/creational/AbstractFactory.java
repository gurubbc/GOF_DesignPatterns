package com.ofss.creational;

public abstract class AbstractFactory {
	abstract Phone getPhone(String phoneType);// this is for returning Phone factory
	abstract Car1 getCar(String carType); // this is for returning Car factory
	
}
