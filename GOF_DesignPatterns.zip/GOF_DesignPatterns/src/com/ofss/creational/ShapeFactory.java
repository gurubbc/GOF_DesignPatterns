package com.ofss.creational;

public class ShapeFactory {

	public static Shape getShape(String shapeName)
	{
		if (shapeName.equalsIgnoreCase("Circle"))
			return new Circle();
		else if (shapeName.equalsIgnoreCase("Square"))
			return new Square();
		else if (shapeName.equalsIgnoreCase("Rectangle"))
			return new Reactangle();
		
		return null;
	}
}
