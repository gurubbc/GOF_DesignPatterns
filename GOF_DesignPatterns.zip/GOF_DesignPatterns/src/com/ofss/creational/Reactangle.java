package com.ofss.creational;

public class Reactangle implements Shape{

	@Override
	public void draw() {
		System.out.println("Drawing Reactangle");
		
	}

}
