package com.ofss.creational;

public class Employee2 implements Cloneable {
	String name;

	public Employee2() {
		super();
		System.out.println("Constructor is called");
		// TODO Auto-generated constructor stub
	}

	public Employee2(String name) {
		super();
		this.name = name;
	}
	
	@Override
	protected Employee2 clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return (Employee2)super.clone();
	}
	
	
	
	
}
