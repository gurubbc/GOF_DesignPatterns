package com.ofss.creational;

class MealBuilder
{
	public Meal prepareVegMeal()
	{
		Meal m=new Meal();
		m.addItem(new VegBurger());
		m.addItem(new Coke());
		return m;
	}
	
	public Meal prepareNonVegMeal()
	{
		Meal m=new Meal();
		m.addItem(new NonVegBurger());
		m.addItem(new Pepsi());
		m.addItem(new Pepsi());
		return m;
	}
}
