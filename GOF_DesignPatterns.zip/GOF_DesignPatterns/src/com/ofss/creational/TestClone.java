package com.ofss.creational;

public class TestClone {

	public static void main(String[] args) throws CloneNotSupportedException {
		// Step 1: Create an object manually using new operator
		System.out.println("Original object creation");
		Employee2 e1=new Employee2(); // mem loc 123
		System.out.println(e1.hashCode());
		
		// Step 2: Clone this into e2
		System.out.println("Cloning starts");
		Employee2 e2=e1.clone(); // mem loc 234
		System.out.println(e2.hashCode());

	}

}
