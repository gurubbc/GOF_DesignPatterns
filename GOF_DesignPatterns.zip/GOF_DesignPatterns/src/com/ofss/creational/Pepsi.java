package com.ofss.creational;

class Pepsi extends coolDrink
{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}

	@Override
	public double price() {
		// TODO Auto-generated method stub
		return 22;
	}
	
}
