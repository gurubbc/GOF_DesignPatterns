package com.ofss.creational;

public interface Shape {
	public void draw();
}
