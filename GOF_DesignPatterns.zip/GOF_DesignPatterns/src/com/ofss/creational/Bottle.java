package com.ofss.creational;

class Bottle implements Packing
{

	@Override
	public String pack() {
		// TODO Auto-generated method stub
		return "Bottle";
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Bottle";
	}
	
}
