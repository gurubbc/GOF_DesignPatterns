package com.ofss.creational;

public class SimpleCar implements Car1{

	@Override
	public void carDetails() {
		System.out.println("Simple Car");
		
	}

}
