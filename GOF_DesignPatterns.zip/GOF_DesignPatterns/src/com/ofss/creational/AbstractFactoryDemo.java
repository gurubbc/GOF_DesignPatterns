package com.ofss.creational;

public class AbstractFactoryDemo {

	public static void main(String[] args) {
		// 2 steps
		
		// Step 1: Return the factory type
		AbstractFactory carFactory=FactoryProducer.getFactory("car");
		// Step 2: Return specific car object
		Car1 simpleCar=carFactory.getCar("simple");
		simpleCar.carDetails();
		
		// Step 2: Return specific car object
		Car1 suvCar=carFactory.getCar("suv");
		suvCar.carDetails();
		
		// Step 1: Return the factory type
		AbstractFactory phoneFactory=FactoryProducer.getFactory("phone");
		// Step 2: Return specific phone object
		Phone p1=phoneFactory.getPhone("mobile");
		p1.phoneDetails();
		//Step 2: Return specific phone object	
		Phone p2=phoneFactory.getPhone("smart");
		p2.phoneDetails();
		
	}

}
