package com.ofss.creational;

public class TestEmployee {

	public static void main(String[] args) {
//		Employee e1=new Employee(); // 1st obj in heap
//		Employee e2=new Employee(); // 2nd obj in heap
		
		Employee e1=Employee.getEmployeeInstance();
		Employee e2=Employee.getEmployeeInstance();
		
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
		

	}

}
