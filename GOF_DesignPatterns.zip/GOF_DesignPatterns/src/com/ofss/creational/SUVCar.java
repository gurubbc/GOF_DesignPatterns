package com.ofss.creational;

public class SUVCar implements Car1 {

	@Override
	public void carDetails() {
		System.out.println("SUV Car");
		
	}

}
