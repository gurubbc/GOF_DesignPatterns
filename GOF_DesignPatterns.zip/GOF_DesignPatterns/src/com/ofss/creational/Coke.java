package com.ofss.creational;

class Coke extends coolDrink
{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Coke";
	}

	@Override
	public double price() {
		// TODO Auto-generated method stub
		return 22;
	}
	
}
