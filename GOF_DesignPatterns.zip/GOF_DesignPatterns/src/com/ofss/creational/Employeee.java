package com.ofss.creational;

public class Employeee implements Cloneable{
	int empId;
	String empName;
	Address add;
	
	public Employeee() {
		super();
		System.out.println("Constructor is called");
	}

	public Employeee(int empId, String empName, Address add) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.add = add;
	}

	@Override
	public String toString() {
		return "Employeee [empId=" + empId + ", empName=" + empName + ", add=" + add + "]";
	}
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		Address aa=new Address(); // empty object of Address
		Employeee eTemp=(Employeee)super.clone();
		eTemp.add=aa;
		return eTemp;
		
	}
	
	
	
	
	
	

}
