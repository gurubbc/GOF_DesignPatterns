package com.ofss.creational;

public class MobilePhone implements Phone{

	@Override
	public void phoneDetails() {
		System.out.println("MobilePhone");
		
	}

}
