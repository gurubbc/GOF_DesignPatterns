package com.ofss.creational;

public class PhoneFactory extends AbstractFactory{

	Phone phone=null;
	
	@Override
	Phone getPhone(String phoneType) {
		if (phoneType.equalsIgnoreCase("mobile"))
			phone=new MobilePhone();
		else if (phoneType.equalsIgnoreCase("smart"))
			phone=new SmartPhone();
		return phone;
	}

	@Override
	Car1 getCar(String carType) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
