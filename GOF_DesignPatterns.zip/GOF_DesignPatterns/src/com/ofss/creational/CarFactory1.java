package com.ofss.creational;

public class CarFactory1 extends AbstractFactory{

	Car1 car=null;
	
	@Override
	Phone getPhone(String phoneType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Car1 getCar(String carType) {
		if (carType.equalsIgnoreCase("Simple"))
			car=new SimpleCar();
		else if (carType.equalsIgnoreCase("SUV"))
			car=new SUVCar();

		return car;
	}

}
