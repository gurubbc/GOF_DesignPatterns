package com.ofss.creational;

import java.util.ArrayList;
import java.util.List;

class Meal
{
	private List<Item> items=new ArrayList();
	
	
	public void addItem(Item item)
	{
		items.add(item);
	}
	
	public double getCost()
	{
		double total=0;
		
		for (Item it:items)
		{
			total+=it.price();
		}
		return total;
	}
	
	public void showItems()
	{
		for (Item i:items)
		{
			System.out.println(i.name()+" costs "+i.price()+" comes in "+i.packing());
		}
	}
}
