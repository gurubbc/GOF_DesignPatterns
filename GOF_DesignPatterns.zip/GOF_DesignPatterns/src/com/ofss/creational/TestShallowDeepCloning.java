package com.ofss.creational;

public class TestShallowDeepCloning {

	public static void main(String[] args) throws CloneNotSupportedException {
		Address a=new Address(11, "Bangalore","Main street");
		
		Employeee e1=new Employeee(1, "Guru", a);
		
		System.out.println(e1);
		
		Employeee e2=(Employeee) e1.clone();
		System.out.println(e2);
		
		e2.add.city="mumbai";
		
		System.out.println(e1);
		System.out.println(e2);
		

	}

}
