package com.ofss.creational;

public class FactoryPatternDemo {

	public static void main(String[] args) {
		// This factory class will create the object depends on your requirements
		Shape s1=ShapeFactory.getShape("circle");
		s1.draw();
		
		Shape s2=ShapeFactory.getShape("rectangle");
		s2.draw();

	}

}
