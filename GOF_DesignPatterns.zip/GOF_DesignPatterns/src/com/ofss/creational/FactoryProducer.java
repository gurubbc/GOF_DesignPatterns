package com.ofss.creational;

public class FactoryProducer {
	public static AbstractFactory getFactory(String factoryType)
	{
		if (factoryType.equalsIgnoreCase("car"))
			return new CarFactory1();
		else if (factoryType.equalsIgnoreCase("phone"))
			return new PhoneFactory();
		else
			return null;
	}
}
