package com.ofss.creational;

public class BuilderPattern {

	public static void main(String[] args) {
		MealBuilder mb=new MealBuilder();
		Meal m1=mb.prepareVegMeal();
		Meal m2=mb.prepareNonVegMeal();
		m1.showItems();
		System.out.println("Total cost is "+m1.getCost());
		m2.showItems();
		System.out.println("Total cost is "+m2.getCost());
			
	}

}
