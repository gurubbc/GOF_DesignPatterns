package com.ofss.creational;
class Wrapper implements Packing
{

	@Override
	public String pack() {
		// TODO Auto-generated method stub
		return "Wrapper";
	}
	
	@Override
	public String toString() {
		return "wrapper";
	}
}
