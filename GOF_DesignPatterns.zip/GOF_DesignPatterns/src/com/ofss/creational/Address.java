package com.ofss.creational;

public class Address {
	int flatNo;
	String city, streetName;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(int flatNo, String city, String streetName) {
		super();
		this.flatNo = flatNo;
		this.city = city;
		this.streetName = streetName;
	}
	@Override
	public String toString() {
		return "Address [flatNo=" + flatNo + ", city=" + city + ", streetName=" + streetName + "]";
	}
	
	
	
}
