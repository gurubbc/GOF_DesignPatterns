package com.ofss.creational;

class VegBurger extends Burger
{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Veg burger";
	}

	@Override
	public double price() {
		// TODO Auto-generated method stub
		return 22;
	}
	
}
