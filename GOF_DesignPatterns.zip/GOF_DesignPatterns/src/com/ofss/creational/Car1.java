package com.ofss.creational;

public interface Car1 {
	void carDetails();
}
