package com.ofss.creational;

public class Employee {
	int empId;
	String empName;
	static Employee emp=null;
	
	private Employee() {
		super();
		System.out.println("Constructor is called");
	}
	
	
	public static Employee getEmployeeInstance()
	{
		if (emp==null)
			emp=new Employee();
		return emp;
	}
	

}
