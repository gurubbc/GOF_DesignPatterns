package com.ofss.creational;

class NonVegBurger extends Burger
{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "NV Burger";
	}

	@Override
	public double price() {
		// TODO Auto-generated method stub
		return 55;
	}
	
}

