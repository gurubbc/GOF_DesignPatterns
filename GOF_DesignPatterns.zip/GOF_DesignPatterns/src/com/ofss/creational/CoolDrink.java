package com.ofss.creational;

abstract class coolDrink implements Item
{
	@Override
	public Packing packing()
	{
		return new Bottle();
	}

}

