package com.ofss.creational;
interface Packing
{
	public String pack();
}
