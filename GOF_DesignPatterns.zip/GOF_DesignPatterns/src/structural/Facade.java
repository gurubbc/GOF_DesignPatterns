package structural;

import java.util.ArrayList;

public class Facade {

	public static void main(String[] args) {
			
		ArrayList<Emp> allManagers=listAllManagers();
		
		for (Emp e:allManagers)
		{
			System.out.println(e.username+" "+e.designation);
		}
		
	}
	
	public static ArrayList<Emp> listAllManagers()
	{
		boolean con=DBConnection.connectDB("Guru", "Guru");
		ArrayList<Emp> managers=new ArrayList<Emp>();
		if (con==true)
		{
			ArrayList<Emp> allEmps=Employees.listAllEmployees();
			managers=Employees.filterManagers();
			
		}
		return managers;
		
	}
}
