package structural;

public class Adapter {
	public static void main(String[] args) {
		
		IndianPlugImpl i=new IndianPlugImpl();
		i.powerOnIndia();
		
		USPlugImpl u=new USPlugImpl();
		u.powerOnUSA();
		
		
		USPlugToIndianPlugAdapter uu=new USPlugToIndianPlugAdapter(u);
		uu.powerOnIndia();
		
	}
}
