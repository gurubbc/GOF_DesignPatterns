package structural;

public class NewsPaper extends Document{

	public NewsPaper(Workshop ws1, Workshop ws2) {
		super(ws1, ws2);
	}
	
	@Override
	public void manufacture() {
		System.out.println("Producing Newspaper");
		
		for (Workshop ws:workShops)
		{
			ws.work();//generic method that will be resolved to print, bind, fold, wrap dynamically
		}
	}

}
