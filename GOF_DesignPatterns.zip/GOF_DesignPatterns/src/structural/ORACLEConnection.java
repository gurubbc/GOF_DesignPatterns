package structural;

class ORACLEConnection implements DBConenction1
{
	public void getConnection()
	{
		System.out.println("GIVES YOU ORACLE BD SERVER CONNECTION");
	}
}
