package structural;

class JavaProgrammer implements Programmer
{

	@Override
	public void code() {
		System.out.println("Writing Code in Java");

	}
}
