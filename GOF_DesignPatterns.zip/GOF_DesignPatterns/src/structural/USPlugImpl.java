package structural;

class USPlugImpl implements USPlug
{

	@Override
	public void powerOnUSA() {
		System.out.println("USA plug power on");
		
	}
}
