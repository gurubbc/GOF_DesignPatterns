package structural;

class Emp
{
	String username;
	String designation;
	public Emp(String username, String designation) {
		super();
		this.username = username;
		this.designation = designation;
	}
	public String getDesignation() {
		return designation;
	}
	
	
	
}
