package structural;

import java.util.*;

class Employee
{
	String name, designation;
	ArrayList<Employee> subordinates=new ArrayList<Employee>();
	
	public Employee(String name, String designation) {
		super();
		this.name = name;
		this.designation = designation;
	}
	
	public void addSubordinate(Employee sub)
	{
		subordinates.add(sub);
	}

	public ArrayList<Employee> getSubordinates() {
		return subordinates;
	}
	
	public void removeSubordinate(Employee e)
	{
		// Check to see if "e" exists in the subordinate list, then only remo ve
		// else, throw user defined exception (NoSuchSubordinateExistsException)
		subordinates.remove(e);
	}
}
