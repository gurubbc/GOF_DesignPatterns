package structural;

interface IndianPlug
{
	public void powerOnIndia();
}
