package structural;

class ConnectionDetails
{
	public static boolean connect(String username, String password)
	{
		String dbname="oracle";
		double portNo=1521;
		String machineName="mymachine";
		
		// some logic
		
		return true;
	}
}
