package structural;

class MySQLConnection implements DBConenction1
{
	public void getConnection()
	{
		System.out.println("GIVES YOU MySQL CONNECTION");
	}
}
