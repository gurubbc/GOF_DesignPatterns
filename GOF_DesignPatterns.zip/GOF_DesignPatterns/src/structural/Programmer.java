package structural;

interface Programmer{
	void code();
}
