package structural;

interface Workshop
{
	void work();
}
