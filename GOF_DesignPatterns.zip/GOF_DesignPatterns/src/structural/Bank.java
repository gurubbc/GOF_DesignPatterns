package structural;

interface Bank
{
	public void shopOnline(double amt) throws Exception;
}
