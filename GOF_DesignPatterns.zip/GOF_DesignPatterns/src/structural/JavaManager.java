package structural;

class JavaManager extends ProgrammerDecorator
{

	public JavaManager(Programmer decoratedProgrammer) {
		super(decoratedProgrammer);
	}

	@Override
	public void code()
	{
		decoratedProgrammer.code(); // coding part
		manageJavaProjects(decoratedProgrammer); // managing part, extension part
		
	}

	// additional responsibility given to object
	private void manageJavaProjects(Programmer decoratedProgrammer)
	{
		System.out.println("Manages Java Projects");
	}
}
