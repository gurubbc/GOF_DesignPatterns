package structural;

class IndianPlugImpl implements IndianPlug
{

	@Override
	public void powerOnIndia() {
		System.out.println("Indian Plug power on");
		
	}
}
