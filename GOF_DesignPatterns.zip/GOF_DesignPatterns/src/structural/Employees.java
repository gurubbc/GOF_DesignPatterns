package structural;

import java.util.ArrayList;

class Employees
{
	public static ArrayList<Emp> allEmployees=new ArrayList<Emp>();
	public static ArrayList<Emp> managers=new ArrayList<Emp>();
	
	public static ArrayList<Emp> listAllEmployees()
	{
	
	Emp e1=new Emp("guru","trainer");
	Emp e2=new Emp("Peter","manager");
	Emp e3=new Emp("Abhijeet","manager");
	allEmployees.add(e1);
	allEmployees.add(e2);
	allEmployees.add(e3);
	return allEmployees;
	}
	
	public static ArrayList<Emp> filterManagers()
	{
		for (Emp e:allEmployees)
		{
			if (e.getDesignation().equalsIgnoreCase("manager"))
				managers.add(e);
		}
		return managers;
	}
	
	
}
