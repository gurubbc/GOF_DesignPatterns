package structural;

class Wrap implements Workshop
{

	@Override
	public void work() {
		System.out.println("\tWrapped with glassy paper");
		
	}
	
}
