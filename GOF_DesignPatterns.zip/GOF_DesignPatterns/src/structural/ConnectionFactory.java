package structural;

import java.util.HashMap;

class ConnectionFactory
{
	public static HashMap connectionMap=new HashMap(); // DB Connection pool
	
	public static DBConenction1 getConnection(String dbServerName)
	{
		DBConenction1 dbConnection=(DBConenction1) connectionMap.get(dbServerName);
		if (dbConnection==null)
		{
			System.out.println("Connection is not available, going to create new connection");
			System.out.println("Switching "+dbServerName);
			switch(dbServerName)
			{
			case "oracle":  dbConnection=new ORACLEConnection();
			               connectionMap.put("oracle", dbConnection);
			               break;
			case "postgres":  dbConnection=new PostGresConnection();
							connectionMap.put("postgres", dbConnection);
							break;
			case "mysql":  dbConnection=new MySQLConnection();
							System.out.println("Returning mysql connection");
			  			connectionMap.put("mysql", dbConnection);
			               
			}
			
		}
		else {
			System.out.println("This connection is already available, Fetching the connection object from the connection pool");
		}
		return dbConnection;
	}
}
