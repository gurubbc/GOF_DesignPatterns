package structural;

class Print implements Workshop
{

	@Override
	public void work() {
		System.out.println("\tPrinted");
		
	}
	
}
