package structural;

interface DBConenction1
{
	public void getConnection();
}
