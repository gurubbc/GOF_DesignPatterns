package structural;

class ICICIBank implements Bank
{

	@Override
	public void shopOnline(double amt) {
		System.out.println("Successfully paid!!!");

	}

}
