package structural;

interface USPlug
{
	public void powerOnUSA();
}
