package structural;

public class Proxy {

	public static void main(String[] args) {
		Bank bank=new CreditCard();

		try {
			bank.shopOnline(2500);
			bank.shopOnline(3500000);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}


	}
}
