package structural;

class PostGresConnection implements DBConenction1
{
	public void getConnection()
	{
		System.out.println("GIVES YOU PostGres CONNECTION");
	}
}
