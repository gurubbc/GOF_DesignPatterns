package structural;

public class Fold implements Workshop{

	@Override
	public void work() {
		System.out.println("\tFolded");
		
	}

}
