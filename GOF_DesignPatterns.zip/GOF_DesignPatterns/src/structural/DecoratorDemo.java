package structural;

class DecoratorDemo {
	public static void main(String[] args) {
		Programmer javaProgrammer = new JavaProgrammer();
//		javaProgrammer.code();
		
		Programmer javaManager = new JavaManager(javaProgrammer);

//		javaManager.code();
		
		Programmer architect=new JavaArchitect(javaManager);
		architect.code();

	}
}
