package structural;

public class JavaArchitect extends ProgrammerDecorator{

	public JavaArchitect(Programmer decoratedProgrammer) {
		super(decoratedProgrammer);
	}

	@Override
	public void code()
	{
		decoratedProgrammer.code();
		architectJavaProjects(decoratedProgrammer); // extension part
		transferKnowledgeToNewJoinees();// extension part
	}

	// additional responsibility given to object
	private void architectJavaProjects(Programmer decoratedProgrammer)
	{
		System.out.println("Architect Jasva projects");
	}
	
	private void transferKnowledgeToNewJoinees()
	{
		System.out.println("KA session for new joinees");
	}
}
