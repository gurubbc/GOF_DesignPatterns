package structural;

class USPlugToIndianPlugAdapter implements IndianPlug
{
	USPlug uPlug;
	
	public USPlugToIndianPlugAdapter(USPlug uPlug) {
		this.uPlug=uPlug;
	}



	@Override
	public void powerOnIndia() {
		System.out.println("USA PLUG working in India");
		uPlug.powerOnUSA();
		
	}
}
