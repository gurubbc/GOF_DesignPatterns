package structural;

//CreditCard is our proxy to bank
class CreditCard implements Bank
{
	public static final double CARD_LIMIT=250000;
	Bank bank=new ICICIBank();

	@Override
	public void shopOnline(double amt) throws Exception {
		if (amt > CARD_LIMIT)
			throw new Exception("CARD LIMIT CROSSED");
		else
		{
			bank.shopOnline(amt);
		}

	}


}
