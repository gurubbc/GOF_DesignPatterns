package structural;

class DBConnection
{
	public static boolean  connectDB(String username, String password)
	{
		boolean connection=ConnectionDetails.connect("Guru", "Guru");
		return connection;
		
	}
}
