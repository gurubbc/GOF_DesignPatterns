package structural;

public class Bridge {
	public static void main(String[] args) {
//		Document doc1=new Book(new Print(), new Bind());
//		doc1.manufacture();
	
//		Document doc2=new Magazine(new Print(), new Bind(), new Wrap());
//		doc2.manufacture();
//
		Document doc3=new NewsPaper(new Print(), new Fold());
		doc3.manufacture();
	}
}
