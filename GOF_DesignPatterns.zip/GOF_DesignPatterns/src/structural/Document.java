package structural;

abstract class Document
{
	protected Workshop[] workShops;
	
	protected Document(Workshop...workShops)
	{
		this.workShops=workShops;
	}
	
	abstract public void manufacture();
}
