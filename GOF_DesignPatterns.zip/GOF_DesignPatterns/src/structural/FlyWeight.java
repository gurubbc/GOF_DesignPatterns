package structural;

public class FlyWeight {

	public static void main(String[] args) {
		DBConenction1 ora=ConnectionFactory.getConnection("oracle");
		ora.getConnection();
		
		DBConenction1 ora1=ConnectionFactory.getConnection("oracle");
		ora1.getConnection();
		System.out.println(ora+ " "+ ora1);
		
		System.out.println(ora==ora1);
		
		DBConenction1 mysql1=ConnectionFactory.getConnection("mysql");
		mysql1.getConnection();
		
		DBConenction1 mysql2=ConnectionFactory.getConnection("mysql");
		mysql2.getConnection();
		
		DBConenction1 mysql3=ConnectionFactory.getConnection("mysql");
		mysql3.getConnection();
		
		System.out.println(mysql1+"  "+mysql2+" "+mysql3);

		
	}
}
