package structural;

import java.util.ArrayList;

public class Composite {

	public static void main(String[] args) {
		Employee e1=new Employee("Guru","CEO");
		Employee e2=new Employee("Subha","VP");
		Employee e21=new Employee("Abhijeet","SVP");
		Employee e22=new Employee("Kavin", "SVP");
		Employee e3=new Employee("Shruthii","Director");
		Employee e4=new Employee("Srikaanth","Manager");
		
		Employee sales1=new Employee("Peter","Sales Person");
		Employee sales2=new Employee("Hemant","Sales Person");
		Employee sales3=new Employee("Rudra","Sales Person");
		Employee sales4=new Employee("Sam","Sales Person");
		Employee sales5=new Employee("Lakhsmi","Sales Person");
		
		
		e1.addSubordinate(e2);
		e1.addSubordinate(e21);
		e1.addSubordinate(e22);
		e2.addSubordinate(e3);
		e3.addSubordinate(e4);
		e4.addSubordinate(sales1);
		e4.addSubordinate(sales2);
		e4.addSubordinate(sales3);
		e4.addSubordinate(sales4);
		e4.addSubordinate(sales5);
		
		ArrayList<Employee> ceoSubordinate=e1.getSubordinates();
		
		ceoSubordinate.forEach(emp-> {System.out.println(emp.name+" "+emp.designation);});
		
		ArrayList<Employee> managerSubordinates=e4.getSubordinates();
		
		
		System.out.println("Retreiving the reportees for Lakshmi ");
		ArrayList<Employee> allSubs=sales5.getSubordinates();
		allSubs.forEach( emp -> {System.out.println(emp.name+" and "+emp.designation);});
		
		
		System.out.println("Retreiving the reportees for Srikaanth ");
		managerSubordinates.forEach( emp -> {System.out.println(emp.name+" and "+emp.designation);});
		
		e4.removeSubordinate(e1);
		System.out.println("Retreiving the reportees for Srikaanth ");
		managerSubordinates.forEach( emp -> {System.out.println(emp.name+" and "+emp.designation);});
		
		
	}
}
