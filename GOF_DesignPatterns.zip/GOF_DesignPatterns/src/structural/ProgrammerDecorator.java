package structural;

class ProgrammerDecorator implements Programmer
{
	protected Programmer decoratedProgrammer;

	public ProgrammerDecorator(Programmer decoratedProgrammer) {
		super();
		this.decoratedProgrammer = decoratedProgrammer;
	}

	public void code()
	{
		decoratedProgrammer.code();
	}
}
