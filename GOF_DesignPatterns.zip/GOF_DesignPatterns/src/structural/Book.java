package structural;

class Book extends Document
{
	public Book(Workshop workShop1, Workshop workShop2)
	{
		super(workShop1, workShop2);
	}
	
	@Override
	public void manufacture() {
		System.out.println("Book");
		for (Workshop ws: workShops)
		{
			ws.work();
		}
	}
}
