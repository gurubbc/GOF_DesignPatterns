class Vehicle {
    protected String manufacturer;
    protected String model;

    public void startEngine() {
        System.out.println("Engine started.");
    }

    public void accelerate() {
        System.out.println("Accelerating...");
    }
}

class Car extends Vehicle {
    private int numberOfDoors;

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    public void openTrunk() {
        System.out.println("Trunk opened.");
    }
}

class Motorcycle extends Vehicle {
    private boolean hasSideCar;

    public void setHasSideCar(boolean hasSideCar) {
        this.hasSideCar = hasSideCar;
    }

    public void wheelie() {
        System.out.println("Performing a wheelie!");
    }
}



public class LiskovDemo {

	
	public static void m1(Vehicle v) 
	{
		if (v instanceof Motorcycle)
		{
			((Motorcycle)v).wheelie();
		} else
			if (v instanceof Car)
			{
				((Car)v).openTrunk();
			}
	}
	
	public static void main(String[] args) {
		Vehicle v1=new Car();
		v1.accelerate();
		v1.startEngine();
		
		Vehicle v2=new Motorcycle();
		v2.startEngine();
		v2.accelerate();
		
		m1(v2);
		m1(v1);

	}

}
