interface AudioPlayer {
    void playAudio();
    void pauseAudio();
    void stopAudio();
}

interface VideoPlayer {
    void playVideo();
    void pauseVideo();
    void stopVideo();
}

interface MediaPlayer extends AudioPlayer, VideoPlayer {
    void play();
    void pause();
    void stop();
}

class BasicMediaPlayer implements MediaPlayer {
    public void playAudio() {
        System.out.println("Audio is playing.");
    }

    public void pauseAudio() {
        System.out.println("Audio playback paused.");
    }

    public void stopAudio() {
        System.out.println("Audio playback stopped.");
    }

    public void playVideo() {
        System.out.println("Video is playing.");
    }

    public void pauseVideo() {
        System.out.println("Video playback paused.");
    }

    public void stopVideo() {
        System.out.println("Video playback stopped.");
    }

    public void play() {
        System.out.println("Media playback started.");
    }

    public void pause() {
        System.out.println("Media playback paused.");
    }

    public void stop() {
        System.out.println("Media playback stopped.");
    }
}

class AudioPlayerOnly implements AudioPlayer {
    public void playAudio() {
        System.out.println("Audio is playing.");
    }

    public void pauseAudio() {
        System.out.println("Audio playback paused.");
    }

    public void stopAudio() {
        System.out.println("Audio playback stopped.");
    }
}

class VideoPlayerOnly implements VideoPlayer {
    public void playVideo() {
        System.out.println("Video is playing.");
    }

    public void pauseVideo() {
        System.out.println("Video playback paused.");
    }

    public void stopVideo() {
        System.out.println("Video playback stopped.");
    }
}


public class InterfaceSegregationPrinciple 
{
	public static void main(String[] args) {
		BasicMediaPlayer bmp=new BasicMediaPlayer();
		bmp.play();
		bmp.playAudio();
		bmp.playVideo();
		
		AudioPlayerOnly apo=new AudioPlayerOnly();
		apo.playAudio();
		
	}
}